?package(mobile-jolokia-client):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="mobile-jolokia-client" command="/usr/bin/mobile-jolokia-client"
