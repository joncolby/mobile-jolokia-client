# Defaults for mobile-jolokia-client initscript
# sourced by /etc/init.d/mobile-jolokia-client
# installed at /etc/default/mobile-jolokia-client by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
